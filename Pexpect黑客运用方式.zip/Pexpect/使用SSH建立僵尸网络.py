#encoding:utf-8
import os;
import pxssh;
class Client:
	def __init__(self,host,user,pwd):
		self.Host = host;
		self.User = user;
		self.Pwd  = pwd;
		self.connect();
	
	def connect(self):
		try:
			px = pxssh.pxssh();
			px.login(self.Host,self.User,self.Pwd);
			self.px = px;
		except Exception,e:
			print e;
			print "[-]Connect faild;";
	

	def SendMsg(self,CommandStr):
		self.px.sendline(CommandStr);
		self.px.prompt();
		return self.px.before;



Consolers=[];
def SendCommand(Msg):
	for ele in Consolers:
		Msg=ele.SendMsg(Msg);
		print "[+]MSG:"+Msg;
	None;

def NewConsoler(host,user,pwd):
	px = Client(host,user,pwd);
	Consolers.append(px);


NewConsoler("192.168.0.103","root","100100");
NewConsoler("192.168.0.103","root","100100");
NewConsoler("192.168.0.103","root","100100");
SendCommand("uname -a");







		
