#encoding:utf-8
import os;
import pexpect;
Expect_Arr = ['#','>>>',">","\$"];
def SendLine(PexObj,Msg):
	PexObj.sendline(Msg);
	PexObj.expect(Expect_Arr);
	print "[+]",PexObj.before;
	return;

def CreatePexObj(host,user,pwd):
	CmdStr = "ssh "+user+"@"+host;
	PexObj = pexpect.spawn(CmdStr);
	#这里expect 有时候会看成 except 要注意
	ret=PexObj.expect([pexpect.TIMEOUT,"Are you sure you want to continue connecting","[P|p]assword"]);
	if ret==0:
		print "[-]Faild: Connect Error!!!";
		return;
	if ret==1:
		PexObj.sendline("yes");
		ret=PexObj.expect([pexpect.TIMEOUT,"[P|p]assword"]);
	if ret==0:
		print "[-]Faild: Connect Error!!!";
		return;
	PexObj.sendline(pwd);
	PexObj.expect(Expect_Arr);#因为它里面有一个队列 也就是说我们接收到一条消息的时候要先取走
	#当下一次再去取的时候才不会取到这次的
	return PexObj;
	

def main():
	user="root";
	pwd="100100";
	host="192.168.0.103";
	PexObj=CreatePexObj(host,user,pwd);
	#SendLine(PexObj,"cat /ect/shadow | grep root");
	while(True):
		CommandStr = raw_input();
		SendLine(PexObj,CommandStr);
	None;

if __name__ == "__main__":
	main();
