#encoding:utf-8
import pxssh;
def SendLine(PxsshObj,Msg):
	PxsshObj.sendline(Msg);
	PxsshObj.prompt();
	print (PxsshObj.before);
	return;
def ConnectSSH(host,user,pwd):
	try:
		PxsshObj = pxssh.pxssh();
		PxsshObj.login(host,user,pwd);
		return PxsshObj;
	except:
		print "[-]Connection error!!!";
		return None;


def main():
	PxsshObj=ConnectSSH("192.168.0.103","root","100100");
	SendLine(PxsshObj,"uname -a");

if __name__ =="__main__":
	main();
	
