#encoding:utf-8
import ftplib;

def AnonLogin(host):
	try:
		ftpobj = ftplib.FTP(host);
		ftpobj.login("anonymous","me@your.com");
		print "[+]Target allow anonymous login";
		ftpobj.quit();
		return True;

	except Exception as e:
		print "[-]Target not allow annoymous login!";
		print "Exception:"+str(e);
	return False;

AnonLogin("192.168.0.103");
