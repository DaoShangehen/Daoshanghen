#encoding:utf-8
import ftplib;
import os;
#import crypt;
Web_ext = ['.jsp','.asp','.aspx','php','.html','.htm','.jspx'];
def ShowWebFile(FtpObj):
	WebPages=[];
	try:
		DirList=FtpObj.nlst();#获取ftp文件列表
		for CurFile in DirList:#遍历每一个元素
			if(os.path.splitext(CurFile)[1] in Web_ext):#判断是不是web页面文件
				print "[+]Web file :"+CurFile;#打印
				WebPages.append(CurFile);
				None;
			None;
		None;
		return WebPages;
	except Exception as e:
		print "\033[1;31;40m[-]Get files list error! e:"+str(e);
		None;
	return 0;


def Main():
	#print "H";
	Host = raw_input("Host>");
	print "[+]Set host ok";
	User = raw_input("User>");
	print "[+]Set user ok";
	Password = raw_input("Password>");	
	try:
		FTPObj = ftplib.FTP(Host);
		FTPObj.login(User,Password);
		ShowWebFile(FTPObj);
	except:
		print "\033[1;31;40m[-]Login error!";
	
	None;



if __name__ == "__main__":
	Main();



