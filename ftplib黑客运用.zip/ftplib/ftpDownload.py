#encoding:utf-8
import ftplib;

ftpobj = ftplib.FTP("192.168.0.103");
ftpobj.login("ftpAdmin","100100");
fp = open("index.php.txt","wb");
ftpobj.retrlines("retr index.php",fp.write);
ftpobj.quit();
