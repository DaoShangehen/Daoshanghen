#encoding: utf-8
import crypt;
def testPass(p_pwd):
	Salt=p_pwd[0:2];#取密文盐的值
	fp = open("密码.txt","r");
	lines= fp.readlines();
	for i in lines:
		Pwd= i.strip("\n");
		CrPwd= crypt.crypt(Pwd,Salt);
		print CrPwd+"==="+p_pwd+":::"+str(CrPwd == p_pwd);
		if( CrPwd == p_pwd):
			return Pwd;
		None;
	return None;


def Main():
	Infos = open("TestPwd.txt","r");
	for line in Infos.readlines():
		if( len(line.strip()) != 0):
			User= line.split(":")[0];
			Pwd=line.split(":")[1];
			print("[*]Check user %s Password Is: %s")%(User,Pwd);
			RetPwd = testPass(Pwd.strip());
			if(RetPwd == None):
				print("[!]Password? I dot'n kown!!!");
			else:
				print("[!]Password is :%s")%(RetPwd);



if __name__ == "__main__":
	Main();
	
